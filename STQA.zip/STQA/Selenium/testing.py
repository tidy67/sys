from selenium import webdriver
import time
driver = webdriver.Chrome()
# webdriver.Chrome().get('https://www.google.com')
driver.get("https://www.google.com")

time.sleep(5)