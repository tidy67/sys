//*[@id="u_0_0_IR"]

//*[@id="u_0_8_Wo"]

//*[@id="u_0_a_JB"]

//*[@id="day"]

//*[@id="month"]

//*[@id="year"]

//*[@id="u_0_d_zy"]/span[1]/label

//*[@id="u_0_d_zy"]/span[2]/label

//*[@id="u_0_d_zy"]/span[3]/label

//*[@id="preferred_pronoun"]

//*[@id="custom_gender"]

//*[@id="u_0_h_O7"]

//input[@id='u_0_h_O7']

//input[@id='password_step_input']

//*[@id="password_step_input"]

//*[@id="u_0_n_fv"]

//*[@id="u_0_n_fv"]/text()

//*[@id="reg_form_box"]/div[12]/a

